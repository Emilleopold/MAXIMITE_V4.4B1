Demonstration programs for the Colour Maximite:

CMM4_TST	a test program that demonstrates various graphics
		on the Colour Maximite running in MODE 4.
 		These include coloured lines, boxes, circles and 
		moving images on the screen using the BLIT command.

COLOUR-1.BAS	Will draw random circles filled with colour

COLOUR-2.BAS	Will show how the MODE command can be used

MUSIC.BAS	Will play a sequence of music files
		First it will copy the files to drive A:
		Then it will play the first.  To play the next press space.

JULIA.BAS	This will plot the Julia set on the Colour Maximite.  
		The Julia set is mathematically similar to the more famous 
		Mandelbrot set and can generate some beautiful images.  Be
		patient as it takes about 15 minutes to calculate.  For more
		see: http://www.thebackshed.com/forum/forum_posts.asp?TID=5103
				